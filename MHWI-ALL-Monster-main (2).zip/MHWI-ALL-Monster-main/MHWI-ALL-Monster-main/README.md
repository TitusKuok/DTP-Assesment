Once you extracted this ZIP file, go to the DTP-Assesment-main folder, open the DTP-Assesment-main folder inside it(yeah idk why they have same name), take out the ghef.db folder, put it in the first DTP-Assesmment-main folder.

ADMIN USERNAME: OSS
ADMIN USERNAME: BOSS
